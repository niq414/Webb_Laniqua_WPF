//Laniqua Webb January 15, 2015 Expressions Assignment

//This calculator will calculate how many packs of hair a hairstylist will need for her scheduled clients

//I typed in 5 for a, 3 for b, and 2 for c and my calculator gave me 38

// The amount of hair packs that each style requires
var boxBraids = a = 5;
var goddessBraids = b = 3;
var upDo = c = 2;

//Determine how many clients are scheduled and which styles they will be getting

var boxBraids = prompt("How many clients are scheduled for Boxed Braids?");
var goddessBraids = prompt("How many clients are scheduled for Goddess Braids");
var upDo = prompt("How many clients are scheduled for an Up-do");

// Multiply each hair style by the amount of hair packs needed and add the amount needed for each style together

var hairPacks = boxBraids * 5 + goddessBraids * 3 + upDo * 2;

//Alert the user of the total amount of hair packs needed based on the hairstyle for each client

console.log("You will need " + hairPacks + " packs of hair.");
alert ("You will need " + hairPacks + " packs of hair!");

//You will need +hairPacks+ of hair.

//I typed in 2 for a, 4 for b, and 10 for c and my calculator gave me 42
